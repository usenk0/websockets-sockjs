# Running this sample

This sample includes two applications, a web app, that we serve through Snowpack, and a Node.js webserver.

```bash
> npm install
> npm run start
```

Our NPM start task will spin up both the API and the webserver.